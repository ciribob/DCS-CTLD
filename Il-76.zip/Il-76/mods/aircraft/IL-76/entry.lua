declare_plugin("IL-76MD",
{
image     	 = "FC.bmp",
installed 	 = true, -- if false that will be place holder , or advertising
dirName	  	 = current_mod_path,
fileMenuName = _("IL-76MD"),

version		 = "1.2.14",
state		 = "installed",
info		 = _("The Boeing KC-135 Tanker is a large military Air to Air refuel aircraft. It was developed for the United States Air Force (USAF) from the 1980s to the early 1990s by McDonnell Douglas. The C-17 carries forward the name of two previous piston-engined military cargo aircraft, the Douglas C-74 Globemaster and the Douglas C-124 Globemaster II. The C-17 commonly performs strategic airlift missions, transporting troops and cargo throughout the world; additional roles include tactical airlift, medical evacuation and airdrop duties."),
binaries	= { 'FC3',},  
InputProfiles =
{
    ["IL-76MD"] = current_mod_path .. '/Input/IL-76MD',
},


Skins	=
	{
		{
			name	= _("IL-76MD"),
			dir		= "Theme"
		},
	},
	
Missions =
	{
		{
			name		= _("IL-76MD"),
			dir			= "Missions",
		},
	},		

LogBook =
	{
		{
			name		= _("IL-76MD"),
			type		= "IL-76MD",
		},
	},		
}
)
----------------------------------------------------------------------------------------

mount_vfs_model_path	(current_mod_path.."/Shapes")
mount_vfs_model_path ("Bazar/World/Shape")
mount_vfs_texture_path("Bazar/World/textures")

dofile(current_mod_path.."/Views.lua")
make_view_settings('IL-76MD', ViewSettings, SnapViews)

make_flyable('IL-76MD', nil, {self_ID,nil,old = 4}, current_mod_path..'/comm.lua')

----------------------------------------------------------------------------------------
plugin_done()