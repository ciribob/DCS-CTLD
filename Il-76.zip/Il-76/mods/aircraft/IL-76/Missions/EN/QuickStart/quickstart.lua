planes = {
    { 
    name = _('F-16A'),
    file = 'F-16A.miz',
    },
}
	 