return plane( "IL-76MD", _("IL-76MD"),
    {
        
        EmptyWeight = "100000",
        MaxFuelWeight = "80000",
        MaxHeight = "12000",
        MaxSpeed = "850",
        MaxTakeOffWeight = "180000",
        Picture = "IL-76MD.png",
        Rate = "70",
        Shape = "IL-76MD",
        WingSpan = "50.5",
        WorldID = 30,
                        
        -- Countermeasures
        SingleChargeTotal = 192,
        CMDS_Incrementation = 32,
        ChaffDefault = 96, -- PPR-26
        ChaffChargeSize = 1,
        FlareDefault = 96, -- PPI-26
        FlareChargeSize = 1,
        CMDS_Edit = true,
        
        singleInFlight = true,

        attribute = {wsType_Air, wsType_Airplane, wsType_Cruiser,IL_76,
        "Transports",
        },
        Categories = {
        },
        Crew = 5,
        CanopyGeometry = makeAirplaneCanopyGeometry(LOOK_AVERAGE, LOOK_BAD, LOOK_BAD),
        mapclasskey = "P0091000029",
    },
    {
    },
    {
    
        aircraft_task(Transport),
    },
	aircraft_task(Transport)
);
