local res = external_profile("Config/Input/Aircrafts/base_joystick_binding.lua")
join(res.keyCommands,{
{down = iCommandPlaneAutopilot, name = 'Autopilot', category = 'Autopilot'},
--{down = iCommandPlaneAUTOnOff, name = 'Autothrust', category = 'Autopilot'},
{down = iCommandPlaneSAUHBarometric, name = 'Autopilot - Barometric Altitude Hold \'H\'', category = 'Autopilot'},
--{down = iCommandPlaneAutopilotOverrideOn, up = iCommandPlaneAutopilotOverrideOff, name = 'Autopilot override (Su-25T)', category = 'Autopilot'},
{down = iCommandPlaneStabTangBank, name = 'Autopilot - Attitude Hold', category = 'Autopilot'},
{down = iCommandPlaneStabHbarBank, name = 'Autopilot - Altitude And Roll Hold', category = 'Autopilot'},
{down = iCommandPlaneStabHorizon,	name = 'Autopilot - Transition To Level Flight Control', category = 'Autopilot'},
{down = iCommandPlaneStabHbar, name = 'Autopilot - Barometric Altitude Hold', category = 'Autopilot'},
{down = iCommandPlaneStabHrad, name = 'Autopilot - Radar Altitude Hold', category = 'Autopilot'},
{down = iCommandPlaneRouteAutopilot, name = 'Autopilot - \'Route following\'', category = 'Autopilot'},
{down = iCommandPlaneStabCancel, name = 'Autopilot Disengage', category = 'Autopilot'},

-- Systems
--{down = iCommandPlaneAirRefuel, name = 'Refueling Boom', category = 'Systems'},
{down = iCommandPlaneJettisonFuelTanks, name = 'Jettison Fuel Tanks', category = 'Systems'},
-- Modes
--{down = iCommandPlaneModeBVR, name = '(2) Beyond Visual Range Mode', category = 'Modes'},
--{down = iCommandPlaneModeVS, name = '(3) Close Air Combat Vertical Scan Mode', category = 'Modes'},
--{down = iCommandPlaneModeBore, name = '(4) Close Air Combat Bore Mode', category = 'Modes'},
--{down = iCommandPlaneModeHelmet, name = '(5) Close Air Combat HMD Helmet Mode', category = 'Modes'},
--{down = iCommandPlaneModeFI0, name = '(6) Longitudinal Missile Aiming Mode', category = 'Modes'},
--{down = iCommandPlaneModeGround, name = '(7) Air-To-Ground Mode', category = 'Modes'},
--{down = iCommandPlaneModeGrid, name = '(8) Gunsight Reticle Switch', category = 'Modes'},

-- Sensors
{combos = {{key = 'JOY_BTN3'}}, down = iCommandPlaneChangeLock, up = iCommandPlaneChangeLockUp, name = 'Target Lock', category = 'Sensors'},
{down = iCommandSensorReset, name = 'Return To Search', category = 'Sensors'},
{down = iCommandPlaneRadarOnOff, name = 'Radar On/Off', category = 'Sensors'},
{down = iCommandPlaneRadarChangeMode, name = 'Radar RWS/TWS Mode Select', category = 'Sensors'},
{down = iCommandPlaneRadarCenter, name = 'Target Designator To Center', category = 'Sensors'},
{down = iCommandPlaneChangeRadarPRF, name = 'Radar Pulse Repeat Frequency Select', category = 'Sensors'},
{down = iCommandPlaneEOSOnOff, name = 'Electro-Optical System On/Off', category = 'Sensors'},
{pressed = iCommandPlaneRadarUp, up = iCommandPlaneRadarStop, name = 'Target Designator Up', category = 'Sensors'},
{pressed = iCommandPlaneRadarDown, up = iCommandPlaneRadarStop, name = 'Target Designator Down', category = 'Sensors'},
{pressed = iCommandPlaneRadarLeft, up = iCommandPlaneRadarStop, name = 'Target Designator Left', category = 'Sensors'},
{pressed = iCommandPlaneRadarRight, up = iCommandPlaneRadarStop, name = 'Target Designator Right', category = 'Sensors'},
{pressed = iCommandSelecterUp, up = iCommandSelecterStop, name = 'Scan Zone Up', category = 'Sensors'},
{pressed = iCommandSelecterDown, up = iCommandSelecterStop, name = 'Scan Zone Down', category = 'Sensors'},
{pressed = iCommandSelecterLeft, up = iCommandSelecterStop, name = 'Scan Zone Left', category = 'Sensors'},
{pressed = iCommandSelecterRight, up = iCommandSelecterStop, name = 'Scan Zone Right', category = 'Sensors'},
{down = iCommandPlaneZoomIn, name = 'Display Zoom In', category = 'Sensors'},
{down = iCommandPlaneZoomOut, name = 'Display Zoom Out', category = 'Sensors'},
{down = iCommandPlaneLaunchPermissionOverride, name = 'Launch Permission Override', category = 'Sensors'},
{down = iCommandDecreaseRadarScanArea, name = 'Radar Scan Zone Decrease', category = 'Sensors'},
{down = iCommandIncreaseRadarScanArea, name = 'Radar Scan Zone Increase', category = 'Sensors'},
{pressed = iCommandPlaneIncreaseBase_Distance, up = iCommandPlaneStopBase_Distance, name = 'Target Specified Size Increase', category = 'Sensors'},
{pressed = iCommandPlaneDecreaseBase_Distance, up = iCommandPlaneStopBase_Distance, name = 'Target Specified Size Decrease', category = 'Sensors'},
{down = iCommandChangeRWRMode, name = 'RWR/SPO Mode Select', category = 'Sensors'},
{down = iCommandPlaneThreatWarnSoundVolumeDown, name = 'RWR/SPO Sound Signals Volume Down', category = 'Sensors'},
{down = iCommandPlaneThreatWarnSoundVolumeUp, name = 'RWR/SPO Sound Signals Volume Up', category = 'Sensors'},

-- Weapons                                                                        
{down = iCommandPlaneSalvoOnOff, name = 'Salvo Mode', category = 'Weapons'},
{down = iCommandChangeGunRateOfFire, name = 'Cut Of Burst select', category = 'Weapons'},
})
-- joystick axes 
join(res.axisCommands,{
{action = iCommandPlaneSelecterHorizontalAbs, name = 'TDC Slew Horizontal'},
{action = iCommandPlaneSelecterVerticalAbs	, name = 'TDC Slew Vertical'},
{action = iCommandPlaneRadarHorizontalAbs	, name = 'Radar Range'},
{action = iCommandPlaneRadarVerticalAbs		, name = 'Radar Vertical'},

{action = iCommandPlaneMFDZoomAbs 			, name = 'MFD Range'},
{action = iCommandPlaneBase_DistanceAbs 	, name = 'Target Base'},
})
return res